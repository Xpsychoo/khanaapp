import React from 'react'
import CloseIcon from './svg/CloseIcon'

export default function Sidebar() {
    return (
        <div className='sidebarWrapper'>
            <div className="navclose">
                <div className="text">
                    Food-hub
                </div>
                <div className="icon">
                    <CloseIcon />
                </div>
            </div>
            <ul className="sidelist">
                <li className="list-item">Home</li>
            </ul>
        </div>
    )
}
